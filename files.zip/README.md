# LocalOCR 🖹

A self-hosted OCR web app that runs entirely on your machine.  
Drop a scanned PDF or image → get clean extracted text in seconds.

**No cloud. No API keys. No data leaves your machine.**

---

## What it does

- Drag & drop PNG, JPG, or multi-page PDF files
- Converts PDFs to images page-by-page (poppler)
- Runs Tesseract OCR on each page
- Returns combined text in a clean browser UI
- Copy to clipboard or download as `.txt`

---

## Architecture

```
Browser (localhost)
    ↓  drag & drop / file picker
Frontend (HTML/CSS/JS)
    ↓  POST /upload  (multipart)
FastAPI backend  :8000
    ↓
detect type (magic bytes)
    ↓
PDF → PNG pages  (pdf2image + poppler)
    ↓
Tesseract OCR on each image
    ↓
merge page text
    ↓
{ "text": "..." }  →  browser displays result
```

---

## Folder structure

```
ocr-app/
├── frontend/
│   ├── pages/
│   │   └── index.html
│   ├── styles/
│   │   └── style.css
│   └── scripts/
│       └── app.js
│
├── backend/
│   ├── app.py          ← FastAPI entry point
│   ├── ocr.py          ← Tesseract wrapper
│   ├── pdf_utils.py    ← PDF → images
│   ├── utils.py        ← helpers
│   └── requirements.txt
│
└── nginx.conf          ← optional: serve frontend on :80
```

---

## Requirements

| Dependency | Purpose | Install |
|---|---|---|
| Python 3.10+ | Backend runtime | [python.org](https://python.org) |
| Tesseract OCR | Text extraction engine | see below |
| Poppler | PDF → image rendering | see below |
| pip packages | FastAPI, pdf2image, etc. | `pip install -r requirements.txt` |

---

## Step 1 — Install Tesseract

### Ubuntu / Debian
```bash
sudo apt-get update
sudo apt-get install tesseract-ocr
# Optional: extra language packs
sudo apt-get install tesseract-ocr-eng  # English (usually pre-installed)
sudo apt-get install tesseract-ocr-hin  # Hindi
# Check: tesseract --version
```

### macOS
```bash
brew install tesseract
# Check: tesseract --version
```

### Windows
1. Download the installer from: https://github.com/UB-Mannheim/tesseract/wiki
2. Run the installer (default path: `C:\Program Files\Tesseract-OCR\`)
3. Add Tesseract to PATH, **or** edit `backend/ocr.py` line:
   ```python
   pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
   ```

---

## Step 2 — Install Poppler (for PDF support)

### Ubuntu / Debian
```bash
sudo apt-get install poppler-utils
```

### macOS
```bash
brew install poppler
```

### Windows
1. Download from: https://github.com/oschwartz10612/poppler-windows/releases
2. Extract and add the `bin/` folder to your PATH.

---

## Step 3 — Install Python dependencies

```bash
cd ocr-app/backend
python -m venv .venv

# Activate:
source .venv/bin/activate       # macOS/Linux
.venv\Scripts\activate          # Windows

pip install -r requirements.txt
```

---

## Step 4 — Start the backend

```bash
# From ocr-app/backend/ with venv active:
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

You should see:
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

Test it:
```bash
curl http://localhost:8000/
# → {"status":"ok","service":"LocalOCR"}
```

---

## Step 5 — Open the frontend

### Quickest way (no web server needed):
Open `frontend/pages/index.html` directly in your browser.  
`file://` origins are allowed by the backend CORS config.

### With Python's built-in server:
```bash
cd ocr-app/frontend/pages
python -m http.server 3000
# Open http://localhost:3000
```

### With nginx (production-style):
1. Edit `nginx.conf` — replace `/path/to/ocr-app` with your real path.
2. Copy to nginx sites:
   ```bash
   sudo cp nginx.conf /etc/nginx/sites-available/localocr
   sudo ln -s /etc/nginx/sites-available/localocr /etc/nginx/sites-enabled/
   sudo nginx -t && sudo systemctl reload nginx
   ```
3. Open `http://localhost`

---

## Usage

1. Open the app in your browser
2. Drag & drop a file onto the upload zone, or click **Browse files**
3. Supported: `.png`, `.jpg`, `.jpeg`, `.pdf` (up to 200 MB)
4. Click **Extract Text →**
5. Watch the status bar: Uploading → Converting → OCR → Done
6. Use **Copy** to copy to clipboard, or **Download .txt** to save

---

## Performance tips

| Scenario | Tip |
|---|---|
| Slow OCR | Lower DPI in `pdf_utils.py` from `300` to `150` |
| Better accuracy | Raise DPI to `400` for small fonts |
| Large batch PDFs | Tesseract is single-threaded per page; pages run sequentially |
| Non-English docs | Install the language pack and pass `lang=` to pytesseract |

### Multi-language example (edit `ocr.py`):
```python
text = pytesseract.image_to_string(img, lang="eng+fra", config=config)
```

---

## Troubleshooting

**`TesseractNotFoundError`**  
Tesseract isn't on PATH. Set the path manually in `ocr.py`:
```python
pytesseract.pytesseract.tesseract_cmd = "/usr/bin/tesseract"
```

**`PDFInfoNotInstalledError`**  
Poppler isn't installed or not on PATH. See Step 2 above.

**CORS error in browser console**  
Make sure the backend is running on port 8000. If you changed the port, update `API_URL` in `frontend/scripts/app.js`.

**Blank output / empty text**  
The scan quality may be too low. Try a higher-resolution scan (300+ DPI at source).

---

## Security note

This app is designed for **localhost only**. Do not expose port 8000 publicly — there is no authentication. If you need multi-user access, add an auth layer and restrict CORS origins.
