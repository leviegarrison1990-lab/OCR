/* ============================================================
   LocalOCR — app.js
   Handles: drag & drop, file validation, upload to backend,
   status steps, copy/download, reset.
   ============================================================ */

const API_URL = 'http://localhost:8000/upload';

// ── DOM refs ──────────────────────────────────────────────────
const dropZone     = document.getElementById('dropZone');
const fileInput    = document.getElementById('fileInput');
const filePreview  = document.getElementById('filePreview');
const fileName     = document.getElementById('fileName');
const fileMeta     = document.getElementById('fileMeta');
const fileTypeIcon = document.getElementById('fileTypeIcon');
const removeBtn    = document.getElementById('removeBtn');
const extractBtn   = document.getElementById('extractBtn');

const statusBar    = document.getElementById('statusBar');
const statusMsg    = document.getElementById('statusMsg');
const progressFill = document.getElementById('progressFill');
const steps        = [1,2,3,4].map(n => document.getElementById(`step${n}`));
const lines        = document.querySelectorAll('.status-line');

const resultArea   = document.getElementById('resultArea');
const resultText   = document.getElementById('resultText');
const charCount    = document.getElementById('charCount');
const copyBtn      = document.getElementById('copyBtn');
const downloadBtn  = document.getElementById('downloadBtn');
const resetBtn     = document.getElementById('resetBtn');

const errorArea    = document.getElementById('errorArea');
const errorMsg     = document.getElementById('errorMsg');
const retryBtn     = document.getElementById('retryBtn');

let currentFile = null;

// ── File validation ───────────────────────────────────────────
const ALLOWED = ['image/png', 'image/jpeg', 'image/jpg', 'application/pdf'];
const MAX_SIZE = 200 * 1024 * 1024; // 200 MB

function validateFile(file) {
  if (!ALLOWED.includes(file.type)) {
    return 'Unsupported type. Use PNG, JPG, or PDF.';
  }
  if (file.size > MAX_SIZE) {
    return `File too large (${formatSize(file.size)}). Max 200 MB.`;
  }
  return null;
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function getIcon(type) {
  if (type === 'application/pdf') return '📑';
  return '🖼️';
}

// ── Accept a file ─────────────────────────────────────────────
function acceptFile(file) {
  const err = validateFile(file);
  if (err) { showError(err); return; }

  currentFile = file;
  fileName.textContent = file.name;
  fileMeta.textContent = formatSize(file.size) + ' · ' + (file.type === 'application/pdf' ? 'PDF' : 'Image');
  fileTypeIcon.textContent = getIcon(file.type);

  hideAll();
  filePreview.hidden = false;
}

// ── Drag & drop ───────────────────────────────────────────────
dropZone.addEventListener('dragenter', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragover',  e => { e.preventDefault(); });
dropZone.addEventListener('dragleave', e => {
  if (!dropZone.contains(e.relatedTarget)) dropZone.classList.remove('drag-over');
});
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) acceptFile(file);
});

dropZone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) acceptFile(fileInput.files[0]);
  fileInput.value = ''; // reset so same file can be re-selected
});

// ── Remove / reset ────────────────────────────────────────────
removeBtn.addEventListener('click', reset);
resetBtn.addEventListener('click',  reset);
retryBtn.addEventListener('click',  () => { hideAll(); filePreview.hidden = false; });

function reset() {
  currentFile = null;
  hideAll();
}

function hideAll() {
  filePreview.hidden = true;
  statusBar.hidden   = true;
  resultArea.hidden  = true;
  errorArea.hidden   = true;
}

// ── Upload & extract ──────────────────────────────────────────
extractBtn.addEventListener('click', uploadAndExtract);

async function uploadAndExtract() {
  if (!currentFile) return;

  hideAll();
  statusBar.hidden = false;
  setStep(0);

  const formData = new FormData();
  formData.append('file', currentFile);

  try {
    // ── Step 1: Uploading
    setStep(0, 'active');
    setMsg('Uploading file…');
    setProgress(15);

    const xhr = new XMLHttpRequest();

    // Track upload progress
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 30);
        setProgress(pct);
      }
    };

    const response = await new Promise((resolve, reject) => {
      xhr.open('POST', API_URL);
      xhr.onload  = () => resolve(xhr);
      xhr.onerror = () => reject(new Error('Network error — is the backend running on localhost:8000?'));
      xhr.send(formData);
    });

    // ── Step 2: Converting
    setStep(1, 'done');
    setStep(1, 'done'); // line 1 done
    markLine(0);
    setStep(1, 'active');
    setMsg('Converting to images…');
    setProgress(45);
    await delay(400); // give UI a beat to show the step

    // ── Step 3: OCR
    markLine(1);
    setStep(2, 'active');
    setMsg('Running Tesseract OCR…');
    setProgress(70);

    if (response.status !== 200) {
      let detail = `Server returned ${response.status}`;
      try { detail = JSON.parse(response.responseText).detail || detail; } catch (_) {}
      throw new Error(detail);
    }

    const data = JSON.parse(response.responseText);

    // ── Step 4: Done
    markLine(2);
    setStep(3, 'active');
    setMsg('Finalising…');
    setProgress(95);
    await delay(300);

    setStep(3, 'done');
    markLine(3);
    setProgress(100);
    setMsg('Done ✓');

    await delay(500);
    statusBar.hidden = true;
    showResult(data.text || '');

  } catch (err) {
    statusBar.hidden = true;
    showError(err.message || 'Unknown error occurred.');
  }
}

// ── Status helpers ────────────────────────────────────────────
function setStep(index, state) {
  // Mark all previous as done, current as active, rest as default
  steps.forEach((s, i) => {
    s.classList.remove('active', 'done');
    if (i < index) s.classList.add('done');
  });
  if (state === 'active') steps[index].classList.add('active');
  if (state === 'done')   steps[index].classList.add('done');
}

function markLine(index) {
  if (lines[index]) lines[index].classList.add('filled');
}

function setMsg(msg) { statusMsg.textContent = msg; }

function setProgress(pct) { progressFill.style.width = pct + '%'; }

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Result ────────────────────────────────────────────────────
function showResult(text) {
  resultText.value = text;
  const chars = text.length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  charCount.textContent = `${chars.toLocaleString()} characters · ${words.toLocaleString()} words`;
  resultArea.hidden = false;
}

// ── Copy ──────────────────────────────────────────────────────
copyBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(resultText.value);
    copyBtn.textContent = 'Copied ✓';
    setTimeout(() => { copyBtn.textContent = 'Copy'; }, 2000);
  } catch (_) {
    resultText.select();
    document.execCommand('copy');
  }
});

// ── Download ──────────────────────────────────────────────────
downloadBtn.addEventListener('click', () => {
  const blob = new Blob([resultText.value], { type: 'text/plain;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const base = (currentFile?.name || 'ocr-result').replace(/\.[^.]+$/, '');
  a.href     = url;
  a.download = base + '_ocr.txt';
  a.click();
  URL.revokeObjectURL(url);
});

// ── Error ─────────────────────────────────────────────────────
function showError(msg) {
  errorMsg.textContent = msg;
  errorArea.hidden = false;
}
