"""
LocalOCR — app.py
FastAPI backend. Accepts image/PDF uploads → returns extracted text.

Run with:
    uvicorn app:app --host 0.0.0.0 --port 8000 --reload
"""

import os
import tempfile
import shutil
from pathlib import Path

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from ocr import run_ocr_on_images
from pdf_utils import pdf_to_images
from utils import detect_file_type, cleanup_dir

# ── App setup ────────────────────────────────────────────────
app = FastAPI(
    title="LocalOCR",
    description="Self-hosted OCR API powered by Tesseract",
    version="1.0.0",
)

# Allow the frontend served from any localhost origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost",
        "http://localhost:80",
        "http://localhost:3000",
        "http://127.0.0.1",
        "http://127.0.0.1:80",
        "null",  # file:// opened directly in browser
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_MIMETYPES = {
    "image/png",
    "image/jpeg",
    "image/jpg",
    "application/pdf",
}

MAX_FILE_SIZE = 200 * 1024 * 1024  # 200 MB


# ── Health check ─────────────────────────────────────────────
@app.get("/")
def health():
    return {"status": "ok", "service": "LocalOCR"}


# ── Main OCR endpoint ─────────────────────────────────────────
@app.post("/upload")
async def upload_and_ocr(file: UploadFile = File(...)):
    """
    Accept an image (PNG/JPG) or PDF, run Tesseract OCR,
    and return the combined extracted text.
    """

    # ── Validate content type ─────────────────────────────────
    content_type = file.content_type or ""
    if content_type not in ALLOWED_MIMETYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{content_type}'. Accepted: PNG, JPG, PDF.",
        )

    # ── Read file into memory ─────────────────────────────────
    file_bytes = await file.read()
    if len(file_bytes) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"File too large ({len(file_bytes)/(1024*1024):.1f} MB). Max 200 MB.",
        )

    # ── Re-check type by magic bytes (more reliable than MIME) ─
    detected = detect_file_type(file_bytes)
    if detected not in ("pdf", "image"):
        raise HTTPException(
            status_code=415,
            detail="Could not detect a valid image or PDF from the file content.",
        )

    # ── Work in a temp directory ──────────────────────────────
    work_dir = tempfile.mkdtemp(prefix="localocr_")
    try:
        original_path = Path(work_dir) / (file.filename or "upload")
        original_path.write_bytes(file_bytes)

        # ── Convert PDF → images (or pass image through) ──────
        if detected == "pdf":
            image_paths = pdf_to_images(str(original_path), work_dir)
        else:
            image_paths = [str(original_path)]

        if not image_paths:
            raise HTTPException(
                status_code=422,
                detail="Could not extract any pages from the file.",
            )

        # ── Run Tesseract on each image ────────────────────────
        extracted_text = run_ocr_on_images(image_paths)

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"OCR processing failed: {str(exc)}",
        )
    finally:
        cleanup_dir(work_dir)

    return JSONResponse({"text": extracted_text})
