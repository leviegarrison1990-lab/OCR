"""
LocalOCR — ocr.py
Runs Tesseract OCR on a list of image file paths.
Returns combined text from all pages.
"""

import os
import pytesseract
from PIL import Image, ImageFilter, ImageEnhance


# If Tesseract is not on PATH, set it explicitly here:
# Windows example:
#   pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# Linux/macOS — usually not needed if installed via package manager.


def preprocess_image(img: Image.Image) -> Image.Image:
    """
    Light preprocessing to improve OCR accuracy on scanned docs.
    - Convert to greyscale
    - Sharpen slightly
    - Increase contrast
    """
    img = img.convert("L")                             # Greyscale
    img = img.filter(ImageFilter.SHARPEN)              # Sharpen
    img = ImageEnhance.Contrast(img).enhance(1.5)      # Boost contrast
    return img


def run_ocr_on_image(image_path: str) -> str:
    """Run Tesseract on a single image and return the extracted text."""
    img = Image.open(image_path)
    img = preprocess_image(img)

    # --oem 1: LSTM engine  --psm 3: fully automatic page segmentation
    config = "--oem 1 --psm 3"
    text = pytesseract.image_to_string(img, config=config)
    return text.strip()


def run_ocr_on_images(image_paths: list[str]) -> str:
    """
    Run OCR on multiple images (e.g. pages of a PDF).
    Returns all text joined with page separators.
    """
    pages = []
    for idx, path in enumerate(image_paths, start=1):
        page_text = run_ocr_on_image(path)
        if len(image_paths) > 1:
            header = f"--- Page {idx} ---"
            pages.append(f"{header}\n{page_text}")
        else:
            pages.append(page_text)

    return "\n\n".join(pages)
