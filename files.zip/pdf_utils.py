"""
LocalOCR — pdf_utils.py
Converts each page of a PDF into a PNG image using pdf2image (poppler).
"""

import os
from pathlib import Path

from pdf2image import convert_from_path
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError,
)


# Resolution for rendering — 300 DPI is good for OCR accuracy
# Lower (150) is faster but may hurt accuracy on small fonts
DPI = 300


def pdf_to_images(pdf_path: str, output_dir: str) -> list[str]:
    """
    Convert every page of a PDF to a PNG file.

    Args:
        pdf_path:   Full path to the source PDF.
        output_dir: Directory where PNG files will be saved.

    Returns:
        Sorted list of absolute paths to the generated PNG files.

    Raises:
        RuntimeError: If poppler is not found or the PDF is corrupted.
    """
    try:
        pages = convert_from_path(
            pdf_path,
            dpi=DPI,
            output_folder=output_dir,
            fmt="png",
            output_file="page",   # files named page0001.png, page0002.png, …
            thread_count=4,       # parallel page rendering
            use_pdftocairo=True,  # faster and more accurate than pdftoppm
        )
    except PDFInfoNotInstalledError:
        raise RuntimeError(
            "Poppler not found. Install it:\n"
            "  Ubuntu/Debian: sudo apt-get install poppler-utils\n"
            "  macOS:         brew install poppler\n"
            "  Windows:       Download from https://github.com/oschwartz10612/poppler-windows"
        )
    except PDFPageCountError as e:
        raise RuntimeError(f"Could not read page count from PDF: {e}")
    except PDFSyntaxError as e:
        raise RuntimeError(f"Malformed PDF: {e}")

    # pdf2image may write files to output_dir; collect and sort them
    image_files = sorted(
        str(p) for p in Path(output_dir).glob("page*.png")
    )

    # Fallback: if it returned PIL objects instead of files, save them
    if not image_files and pages:
        image_files = []
        for i, page in enumerate(pages, start=1):
            img_path = os.path.join(output_dir, f"page{i:04d}.png")
            page.save(img_path, "PNG")
            image_files.append(img_path)

    return image_files
