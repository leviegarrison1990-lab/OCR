"""
LocalOCR — utils.py
Small utilities: magic-byte file-type detection, temp dir cleanup.
"""

import os
import shutil


# Magic byte signatures
_PDF_MAGIC   = b"%PDF"
_PNG_MAGIC   = b"\x89PNG"
_JPEG_MAGIC  = b"\xff\xd8\xff"


def detect_file_type(data: bytes) -> str:
    """
    Inspect the first few bytes to determine if this is a PDF or image.

    Returns:
        "pdf"   — PDF document
        "image" — PNG or JPEG image
        "unknown" — anything else
    """
    if data[:4] == _PDF_MAGIC:
        return "pdf"
    if data[:4] == _PNG_MAGIC:
        return "image"
    if data[:3] == _JPEG_MAGIC:
        return "image"
    return "unknown"


def cleanup_dir(directory: str) -> None:
    """
    Silently remove a temporary directory and all its contents.
    Does nothing if the directory doesn't exist.
    """
    try:
        if os.path.isdir(directory):
            shutil.rmtree(directory)
    except Exception:
        pass  # Best-effort cleanup; never raise on cleanup failure
